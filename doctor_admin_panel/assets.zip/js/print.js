	$(document).ready(function() {
    	print_div();
	});

    function print_div() {
    	$('.prescription-print').printThis();
    }